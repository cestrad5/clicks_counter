export default function returnHowManyArguments(...args) {
  return (args.length);
}
