// eslint-disable-next-line import/extensions
import getSanFranciscoDescription from './6-string-interpolation.js';

console.log(getSanFranciscoDescription());
