export default function taskBlock() {
  const task = false;
  const task2 = true;

  return [task, task2];
}
