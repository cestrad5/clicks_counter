/* eslint-disable */
export default function getResponseFromAPI() {
  return new Promise(() => {});
}
