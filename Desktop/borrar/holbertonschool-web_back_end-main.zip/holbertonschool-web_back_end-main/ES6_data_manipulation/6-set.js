export default function setFromArray(array) {
  return new Set(array);
}
