#!/usr/bin/env python3
"""
Python practice module:
defines 4 variables using python annotations
"""

a: int = 1
pi: float = 3.14
i_understand_annotations: bool = True
school: str = "Holberton"
