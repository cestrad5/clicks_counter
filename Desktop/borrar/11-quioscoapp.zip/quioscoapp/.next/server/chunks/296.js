"use strict";
exports.id = 296;
exports.ids = [296];
exports.modules = {

/***/ 296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ QuioscoProvider),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);





const QuioscoContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const QuioscoProvider = ({ children  })=>{
    const { 0: categorias , 1: setCategorias  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: categoriaActual , 1: setCategoriaActual  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: producto1 , 1: setProducto  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: pedido , 1: setPedido  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: nombre , 1: setNombre  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: total1 , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const obtenerCategorias = async ()=>{
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_2___default()('/api/categorias');
        setCategorias(data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        obtenerCategorias();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setCategoriaActual(categorias[0]);
    }, [
        categorias
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const nuevoTotal = pedido.reduce((total, producto)=>producto.precio * producto.cantidad + total
        , 0);
        setTotal(nuevoTotal);
    }, [
        pedido
    ]);
    const handleClickCategoria = (id)=>{
        const categoria = categorias.filter((cat)=>cat.id === id
        );
        setCategoriaActual(categoria[0]);
        router.push('/');
    };
    const handleSetProducto = (producto)=>{
        setProducto(producto);
    };
    const handleChangeModal = ()=>{
        setModal(!modal);
    };
    const handleAgregarPedido = ({ categoriaId , ...producto })=>{
        if (pedido.some((productoState)=>productoState.id === producto.id
        )) {
            // Actualizar la cantidad
            const pedidoActualizado = pedido.map((productoState)=>productoState.id === producto.id ? producto : productoState
            );
            setPedido(pedidoActualizado);
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.success('Guardado Correctamente');
        } else {
            setPedido([
                ...pedido,
                producto
            ]);
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.success('Agregado al Pedido');
        }
        setModal(false);
    };
    const handleEditarCantidades = (id)=>{
        const productoActualizar = pedido.filter((producto)=>producto.id === id
        );
        setProducto(productoActualizar[0]);
        setModal(!modal);
    };
    const handleEliminarProducto = (id)=>{
        const pedidoActualizado = pedido.filter((producto)=>producto.id !== id
        );
        setPedido(pedidoActualizado);
    };
    const colocarOrden = async (e)=>{
        e.preventDefault();
        try {
            await axios__WEBPACK_IMPORTED_MODULE_2___default().post('/api/ordenes', {
                pedido,
                nombre,
                total: total1,
                fecha: Date.now().toString()
            });
            // Resetear la app
            setCategoriaActual(categorias[0]);
            setPedido([]);
            setNombre('');
            setTotal(0);
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.success('Pedido Realizado Correctamente');
            setTimeout(()=>{
                router.push('/');
            }, 3000);
        } catch (error) {
            console.log(error);
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(QuioscoContext.Provider, {
        value: {
            categorias,
            categoriaActual,
            handleClickCategoria,
            producto: producto1,
            handleSetProducto,
            modal,
            handleChangeModal,
            handleAgregarPedido,
            pedido,
            handleEditarCantidades,
            handleEliminarProducto,
            nombre,
            setNombre,
            colocarOrden,
            total: total1
        },
        children: children
    }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuioscoContext);


/***/ })

};
;