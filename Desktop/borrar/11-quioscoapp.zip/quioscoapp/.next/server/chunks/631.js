"use strict";
exports.id = 631;
exports.ids = [631];
exports.modules = {

/***/ 725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ formatearDinero)
/* harmony export */ });
const formatearDinero = (cantidad)=>{
    return cantidad.toLocaleString("en-US", {
        style: "currency",
        currency: "USD"
    });
};


/***/ }),

/***/ 100:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _context_QuioscoProvider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(296);


const useQuiosco = ()=>{
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_context_QuioscoProvider__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useQuiosco);


/***/ }),

/***/ 631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react-modal"
var external_react_modal_ = __webpack_require__(931);
var external_react_modal_default = /*#__PURE__*/__webpack_require__.n(external_react_modal_);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(187);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
// EXTERNAL MODULE: ./hooks/useQuiosco.js
var useQuiosco = __webpack_require__(100);
;// CONCATENATED MODULE: ./components/Categoria.js



const Categoria = ({ categoria  })=>{
    const { categoriaActual , handleClickCategoria  } = (0,useQuiosco/* default */.Z)();
    const { nombre , icono , id  } = categoria;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(categoriaActual === null || categoriaActual === void 0 ? void 0 : categoriaActual.id) === id ? "bg-amber-400" : ""} flex items-center gap-4 w-full border p-5 hover:bg-amber-400`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                width: 70,
                height: 70,
                src: `/assets/img/icono_${icono}.svg`,
                alt: "Imagen Icono"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                className: "text-2xl font-bold hover:cursor-pointer",
                onClick: ()=>handleClickCategoria(id)
                ,
                children: nombre
            })
        ]
    }));
};
/* harmony default export */ const components_Categoria = (Categoria);

;// CONCATENATED MODULE: ./components/Sidebar.js




const Sidebar = ()=>{
    const { categorias  } = (0,useQuiosco/* default */.Z)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                width: 300,
                height: 100,
                src: "/assets/img/logo.svg",
                alt: "imagen logotipo"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: "mt-10",
                children: categorias.map((categoria)=>/*#__PURE__*/ jsx_runtime_.jsx(components_Categoria, {
                        categoria: categoria
                    }, categoria.id)
                )
            })
        ]
    }));
};
/* harmony default export */ const components_Sidebar = (Sidebar);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
;// CONCATENATED MODULE: ./components/Pasos.js


const pasos = [
    {
        paso: 1,
        nombre: "Men\xfa",
        url: "/"
    },
    {
        paso: 2,
        nombre: "Resumen",
        url: "/resumen"
    },
    {
        paso: 3,
        nombre: "Datos y Total",
        url: "/total"
    }, 
];
const Pasos = ()=>{
    const router = (0,router_.useRouter)();
    const calcularProgreso = ()=>{
        let valor;
        if (router.pathname === "/") {
            valor = 2;
        } else if (router.pathname === "/resumen") {
            valor = 50;
        } else {
            valor = 100;
        }
        return valor;
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-between mb-5",
                children: pasos.map((paso)=>/*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>{
                            router.push(paso.url);
                        },
                        className: "text-2xl font-bold",
                        children: paso.nombre
                    }, paso.paso)
                )
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-gray-100 mb-10",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "rounded-full bg-amber-500 text-xs leading-none h-2 text-center text-white progreso",
                    style: {
                        width: `${calcularProgreso()}%`
                    }
                })
            })
        ]
    }));
};
/* harmony default export */ const components_Pasos = (Pasos);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./helpers/index.js
var helpers = __webpack_require__(725);
;// CONCATENATED MODULE: ./components/ModalProducto.js





const ModalProducto = ()=>{
    const { producto , handleChangeModal , handleAgregarPedido , pedido  } = (0,useQuiosco/* default */.Z)();
    const { 0: cantidad , 1: setCantidad  } = (0,external_react_.useState)(1);
    const { 0: edicion , 1: setEdicion  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        if (pedido.some((pedidoState)=>pedidoState.id === producto.id
        )) {
            const productoEdicion = pedido.find((pedidoState)=>pedidoState.id === producto.id
            );
            setEdicion(true);
            setCantidad(productoEdicion.cantidad);
        }
    }, [
        producto,
        pedido
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "md:flex gap-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:w-1/3",
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    width: 300,
                    height: 400,
                    alt: `imagen producto ${producto.nombre}`,
                    src: `/assets/img/${producto.imagen}.jpg`
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "md:w-2/3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: handleChangeModal,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                className: "h-6 w-6",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                stroke: "currentColor",
                                strokeWidth: 2,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    d: "M6 18L18 6M6 6l12 12"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl font-bold mt-5",
                        children: producto.nombre
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "mt-5 font-black text-5xl text-amber-500",
                        children: (0,helpers/* formatearDinero */.y)(producto.precio)
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-4 mt-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "button",
                                onClick: ()=>{
                                    if (cantidad <= 1) return;
                                    setCantidad(cantidad - 1);
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "h-7 w-7",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    stroke: "currentColor",
                                    strokeWidth: 2,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        d: "M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-3xl",
                                children: cantidad
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "button",
                                onClick: ()=>{
                                    if (cantidad >= 5) return;
                                    setCantidad(cantidad + 1);
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "h-7 w-7",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    stroke: "currentColor",
                                    strokeWidth: 2,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        d: "M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        type: "button",
                        className: "bg-indigo-600 hover:bg-indigo-800 px-5 py-2 mt-5 text-white font-bold uppercase rounded",
                        onClick: ()=>handleAgregarPedido({
                                ...producto,
                                cantidad
                            })
                        ,
                        children: edicion ? "Guardar Cambios" : "A\xf1adir al Pedido"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_ModalProducto = (ModalProducto);

// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(819);
;// CONCATENATED MODULE: ./layout/Layout.js









const customStyles = {
    content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)"
    }
};
external_react_modal_default().setAppElement("#__next");
function Layout({ children , pagina  }) {
    const { modal  } = (0,useQuiosco/* default */.Z)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            "Caf\xe9 - ",
                            pagina
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Quosco Cafeter\xeda"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "md:flex",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("aside", {
                        className: "md:w-4/12 xl:w-1/4 2xl:w-1/5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Sidebar, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("main", {
                        className: "md:w-8/12 xl:w-3/4 2xl:w-4/5 h-screen overflow-y-scroll",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(components_Pasos, {}),
                                children
                            ]
                        })
                    })
                ]
            }),
            modal && /*#__PURE__*/ jsx_runtime_.jsx((external_react_modal_default()), {
                isOpen: modal,
                style: customStyles,
                children: /*#__PURE__*/ jsx_runtime_.jsx(components_ModalProducto, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_toastify_.ToastContainer, {})
        ]
    }));
};


/***/ })

};
;