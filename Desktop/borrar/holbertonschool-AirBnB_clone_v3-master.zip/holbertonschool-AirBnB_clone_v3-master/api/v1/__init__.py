"""
This package contains all the routes that manage the backend
in version 1 of the project, in every single file, you'll find 
the endpoints that are available
"""