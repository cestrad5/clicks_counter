function displayMessage(message) {
  console.log(message);
}

module.exports = displayMessage;
